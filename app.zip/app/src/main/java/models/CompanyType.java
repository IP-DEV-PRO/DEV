package models;

public enum CompanyType {
    SPORT, GYM, ENTERTAINMENT
}
